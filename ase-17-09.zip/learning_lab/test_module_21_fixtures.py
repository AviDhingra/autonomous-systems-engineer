import pytest

from target.fleetops.tests.fakes import FakeDeviceRepository


@pytest.fixture()
def repository() -> FakeDeviceRepository:
    repo = FakeDeviceRepository()
    yield repo
    # This line runs after the test finishes.
    repo.items.clear()


def test_first_test_gets_empty_repository(repository: FakeDeviceRepository) -> None:
    assert repository.items == {}
    repository.items["temporary"] = object()  # type: ignore[assignment]


def test_second_test_gets_fresh_repository(repository: FakeDeviceRepository) -> None:
    assert repository.items == {}
